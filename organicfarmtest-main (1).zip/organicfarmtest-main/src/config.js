export const config = {
  chainId: 56,
  contractAddress: "0x6E9F1eAaD6d53e68Cb16fC5C3b1Cb9b14922fdA2",
  scanLink:
    "https://bscscan.com/address/0x6E9F1eAaD6d53e68Cb16fC5C3b1Cb9b14922fdA2",
  twitterLink: 
    "https://twitter.com/bnb_farm",
  discordLink:
    "https://discord.gg/73NX4xAEn5",
  whitepaperLink:
    "https://organic-farm.gitbook.io/organic-farm/",
  telegramLink:
    "https://t.me/bnborganic",
};
